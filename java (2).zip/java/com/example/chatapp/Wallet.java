package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.chatapp.databinding.ActivityShowAllTutorsBinding;
import com.example.chatapp.databinding.ActivityWalletBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

public class Wallet extends AppCompatActivity {

    ActivityWalletBinding binding;
    FirebaseDatabase database;
    ArrayList<PaymentClass> payments;
    WalletAdapter usersAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityWalletBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database = FirebaseDatabase.getInstance();
        payments = new ArrayList<>();
        usersAdapter=new WalletAdapter(this, payments);
        binding.recyclerViewWallet.setAdapter(usersAdapter);
        final float[] TotalAmount = {0};

        database.getReference().child("Payments").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot snapshot1: snapshot.getChildren()){
                    PaymentClass user = snapshot1.getValue(PaymentClass.class);
                    if(user.getReceiverUid().equals(FirebaseAuth.getInstance().getUid())) {
                        payments.add(user);
                        if(!user.getPaymentStatus().equals("Incomplete"))
                        {
                            TotalAmount[0] = TotalAmount[0] +user.getTotalPayment();
                        }
                    }

                }
                usersAdapter.notifyDataSetChanged();
                binding.priceTotal.setText("$"+TotalAmount[0]);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topmenu, menu);
        MenuItem menuItem1 = menu.findItem(R.id.sortByPriceD);
        menuItem1.setVisible(false);
        MenuItem menuItem2 = menu.findItem(R.id.sortByRatingD);
        menuItem2.setVisible(false);
        MenuItem menuItem3 = menu.findItem(R.id.sortByPriceA);
        menuItem3.setVisible(false);
        MenuItem menuItem4 = menu.findItem(R.id.sortByRatingA);
        menuItem4.setVisible(false);
        menuItem4 = menu.findItem(R.id.search);
        menuItem4.setVisible(false);
        menuItem4 = menu.findItem(R.id.ShowIncomp);
        menuItem4.setVisible(true);
        menuItem4 = menu.findItem(R.id.ShowComp);
        menuItem4.setVisible(true);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        if (menuItem.getItemId() == R.id.SignOut) {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(Wallet.this, MainActivity.class));
        } else if (menuItem.getItemId() == R.id.ShowIncomp) {
            payments.clear();
            database.getReference().child("Payments").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    for(DataSnapshot snapshot1: snapshot.getChildren()){
                        PaymentClass user = snapshot1.getValue(PaymentClass.class);
                        if(user.getReceiverUid().equals(FirebaseAuth.getInstance().getUid())) {

                            if(user.getPaymentStatus().equals("Incomplete"))
                            {
                                payments.add(user);
                            }
                        }

                    }
                    usersAdapter.notifyDataSetChanged();

                }


                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }
        else if (menuItem.getItemId() == R.id.ShowComp) {
            payments.clear();
            database.getReference().child("Payments").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        PaymentClass user = snapshot1.getValue(PaymentClass.class);
                        if (user.getReceiverUid().equals(FirebaseAuth.getInstance().getUid())) {

                            if (!user.getPaymentStatus().equals("Incomplete")) {
                                payments.add(user);
                            }
                        }

                    }
                    usersAdapter.notifyDataSetChanged();

                }


                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        return true;
    }
}