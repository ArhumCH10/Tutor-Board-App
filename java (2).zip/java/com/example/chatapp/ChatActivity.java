package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.Manifest;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.ActivityChatBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.jitsi.meet.sdk.BroadcastEvent;
import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetActivityDelegate;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import org.jitsi.meet.sdk.JitsiMeetView;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ChatActivity extends AppCompatActivity {

    ActivityChatBinding binding;
    MessagesAdapter adapter;
    ArrayList<Message> messages;
    FirebaseDatabase database;
    FirebaseStorage storage;

    ProgressDialog dialog;
    boolean isCall = false;
    String senderUid;
    String receiverUid;
    String name, token, n2;
    String senderRoom, receiverRoom;
    final String[] SenderName = new String[1];
    String SenderProfile, SenderToken;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        dialog = new ProgressDialog(this);
        dialog.setMessage("Uploading Attachment...");
        dialog.setCancelable(false);


        messages = new ArrayList<>();

        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String s1 = sh.getString("Status", "");

        if(s1.equals("Students"))
        {
            binding.callperson.setVisibility(View.GONE);
        }

        n2 = getIntent().getStringExtra("username");
        name = getIntent().getStringExtra("name");
        token = getIntent().getStringExtra("token");

        String profilePic = getIntent().getStringExtra("image");

        binding.name.setText(name);
        Glide.with(ChatActivity.this).load(profilePic)
                .placeholder(R.drawable.imageplaceholder)
                .into(binding.profile);
        
        binding.imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        receiverUid = getIntent().getStringExtra("uid");
        senderUid = FirebaseAuth.getInstance().getUid();
        /*Intent intent = new Intent(getApplicationContext(), Payment.class);
        intent.putExtra("ReceiverUid", receiverUid);
        intent.putExtra("MeetingRoom", "MeetingRoom");
        startActivity(intent);*/

        senderRoom = receiverUid;
        receiverRoom = senderUid;

      /*  Intent intent = new Intent(this, Rating.class);
        intent.putExtra("ReceiverUid", senderUid);
        intent.putExtra("SenderUid", receiverUid);
        intent.putExtra("MeetingRoom", "MeetingRoom");
        intent.putExtra("PaymentId","PaymentId");
        intent.putExtra("TotalPayment",4);

        this.startActivity(intent);
*/
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        database.getReference().child("users").child(s1).child(senderUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            User u = snapshot.getValue(User.class);
                            SenderName[0] = u.getName();
                            SenderProfile = u.getProfileImage();
                            SenderToken=u.getToken();

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        binding.callperson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isCall = true;

                if (senderRoom.length() > 0) {
                    Intent intent =new Intent(getApplicationContext(),OutgoingInvitationActivity.class);
                    intent.putExtra("username",name);
                    intent.putExtra("profilePic",profilePic);
                    intent.putExtra("token",token);
                    intent.putExtra("SenderName",SenderName[0]);
                    intent.putExtra("SenderProfile",SenderProfile);
                    intent.putExtra("SenderToken",SenderToken);
                    intent.putExtra("SenderRoom", senderUid);
                    intent.putExtra("ReceiverUid", receiverUid);
                    intent.putExtra("Price", 5);
                    startActivity(intent);
                    IntentFilter intentFilter = new IntentFilter();
                    intentFilter.addAction(BroadcastEvent.Type.CONFERENCE_JOINED.getAction());
                    finish();



                }



            }
        });




        database.getReference().child("presence").child(receiverUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            String status = snapshot.getValue(String.class);
                            if(!status.isEmpty())
                            {
                                if(status.equals("Offline"))
                                {
                                    binding.status.setVisibility(View.GONE);
                                }
                                else {
                                    binding.status.setText(status);
                                    binding.status.setVisibility(View.VISIBLE);
                                }
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        adapter = new MessagesAdapter(this, messages, senderRoom, receiverRoom);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);
       // binding.recyclerView.scrollToPosition(adapter.getItemCount() - 1);

        //binding.ll.ma = true;

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        database.getReference().child("chats").child(senderUid)
                .child(senderRoom)
                .child("messages")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        messages.clear();
                        for(DataSnapshot snapshot1: snapshot.getChildren())
                        {
                            Message message = snapshot1.getValue(Message.class);
                            message.setMessageId(snapshot1.getKey());
                            messages.add(message);
                        }
                        adapter.notifyDataSetChanged();
                        binding.recyclerView.smoothScrollToPosition(binding.recyclerView.getAdapter().getItemCount());

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        binding.sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageTxt = binding.messageBox.getText().toString();
                Date date = new Date();
                Message message = new Message(messageTxt, senderUid, date.getTime());
                binding.messageBox.setText("");

                String randomKey = database.getReference().push().getKey();

                HashMap<String, Object> lastMsgObj = new HashMap<>();
                lastMsgObj.put("lastMsg", message.getMessage());
                lastMsgObj.put("lastMsgTime", date.getTime());
                database.getReference().child("chats").child(senderUid)
                        .child(senderRoom).updateChildren(lastMsgObj);
                database.getReference().child("chats").child(receiverUid)
                        .child(receiverRoom).updateChildren(lastMsgObj);


                database.getReference().child("chats").child(senderUid)
                        .child(senderRoom).child("messages")
                        .child(randomKey)
                        .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        database.getReference().child("chats").child(receiverUid)
                                .child(receiverRoom).child("messages")
                                .child(randomKey)
                                .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                sendNotification(SenderName[0], message.getMessage(), token);
                                binding.recyclerView.smoothScrollToPosition(binding.recyclerView.getAdapter().getItemCount());

                            }
                        });

                        }
                });




            }
        });
        binding.camera.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                boolean pick = true;
                if(pick == true)
                {
                    if(!checkCameraPermission())
                    {
                        requestCameraPermission();
                    }
                    else
                        PickImage();
                }
                else
                {
                    if(!checkStoragePermission())
                    {
                        reqestStoragePermission();
                    }
                    else
                        PickImage();
                }
            }
        });
        binding.attachment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/*");
                startActivityForResult(intent, 25);
            }
        });

        final Handler handler = new Handler();
        binding.messageBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                database.getReference().child("presence").child(senderUid).setValue("typing...");

                handler.removeCallbacksAndMessages(null);
                handler.postDelayed(userStoppedTyping, 1000);
                }
            Runnable userStoppedTyping = new Runnable() {
                @Override
                public void run() {
                    database.getReference().child("presence").child(senderUid).setValue("Online");

                }
            };
        });

        getSupportActionBar().setDisplayShowTitleEnabled(false);
       // getSupportActionBar().setTitle(name);
       // getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void PickImage() {
        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .start(this);
    }

    private boolean checkStoragePermission() {
        boolean res2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        return res2;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void reqestStoragePermission() {
        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void requestCameraPermission() {
        requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);

    }

    private boolean checkCameraPermission() {
        boolean res1 = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean res2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        return res1 && res2;
    }


    void sendNotification(String name, String message, String token)
    {
        try {
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = "https://fcm.googleapis.com/fcm/send";
            JSONObject data = new JSONObject();
            data.put("title", name);
            data.put("body", message);
            JSONObject notificationdata = new JSONObject();
            notificationdata.put("notification", data);
            notificationdata.put("to", token);

            JsonObjectRequest request = new JsonObjectRequest(url, notificationdata, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    })
            {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> map = new HashMap<>();
                    String key = "Key=AAAAzHJtcAU:APA91bENpGRgO9da8TIsXMBrLdRyfVyOJHfF9dU9CIUtc4hX6vayv_z25Vt92HUJ94gaKIb8dbRjdkC2dcBsOGJrWP1tjZvGmqMYPt7LqeykMPVLOfmpXZAJmVNAIo8mCzQSQqxzFMq4";

                    map.put("Content-Type", "application/json");
                    map.put("Authorization",key);
                    return map;
                }
            };
            queue.add(request);

        }catch (Exception ex)
        {

        }

    }
    @Override
    protected void onActivityResult(int requestCode, int resultcode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultcode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultcode == RESULT_OK) {
                Uri resultUri = result.getUri();
                Calendar calendar = Calendar.getInstance();
                StorageReference reference = storage.getReference().child("chats").child(calendar.getTimeInMillis() + "");
                dialog.show();

                reference.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        dialog.dismiss();
                        if(task.isSuccessful())
                        {
                            reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String filePath = uri.toString();
                                    String messageTxt = binding.messageBox.getText().toString();
                                    Date date = new Date();
                                    Message message = new Message(messageTxt, senderUid, date.getTime());

                                    message.setMessage("photo");
                                    message.setImageUrl(filePath);

                                    binding.messageBox.setText("");

                                    String randomKey = database.getReference().push().getKey();

                                    HashMap<String, Object> lastMsgObj = new HashMap<>();
                                    lastMsgObj.put("lastMsg", message.getMessage());
                                    lastMsgObj.put("lastMsgTime", date.getTime());
                                    database.getReference().child("chats").child(senderUid)
                                            .child(senderRoom).updateChildren(lastMsgObj);
                                    database.getReference().child("chats").child(receiverUid)
                                            .child(receiverRoom).updateChildren(lastMsgObj);


                                    database.getReference().child("chats").child(senderUid)
                                            .child(senderRoom).child("messages")
                                            .child(randomKey)
                                            .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            database.getReference().child("chats").child(receiverUid)
                                                    .child(receiverRoom).child("messages")
                                                    .child(randomKey)
                                                    .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {
                                                    sendNotification(SenderName[0], message.getMessage(), token);

                                                }
                                            });

                                        }
                                    });
                                }
                            });
                        }
                    }
                });
            } else if (resultcode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }
        if(requestCode == 25)
        {
            if(data != null)
            {
                if(data.getData() != null)
                {
                    Uri seletechImage = data.getData();
                    Calendar calendar = Calendar.getInstance();
                    StorageReference reference = storage.getReference().child("chats").child(calendar.getTimeInMillis() + "");
                    dialog.show();

                    reference.putFile(seletechImage).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            dialog.dismiss();
                            if(task.isSuccessful())
                            {
                                reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        String filePath = uri.toString();
                                        String messageTxt = binding.messageBox.getText().toString();
                                        Date date = new Date();
                                        Message message = new Message(messageTxt, senderUid, date.getTime());

                                        message.setMessage("doc");
                                        message.setImageUrl(filePath);

                                        binding.messageBox.setText("");

                                        String randomKey = database.getReference().push().getKey();

                                        HashMap<String, Object> lastMsgObj = new HashMap<>();
                                        lastMsgObj.put("lastMsg", message.getMessage());
                                        lastMsgObj.put("lastMsgTime", date.getTime());
                                        database.getReference().child("chats").child(senderUid)
                                                .child(senderRoom).updateChildren(lastMsgObj);
                                        database.getReference().child("chats").child(receiverUid)
                                                .child(receiverRoom).updateChildren(lastMsgObj);


                                        database.getReference().child("chats").child(senderUid)
                                                .child(senderRoom).child("messages")
                                                .child(randomKey)
                                                .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                database.getReference().child("chats").child(receiverUid)
                                                        .child(receiverRoom).child("messages")
                                                        .child(randomKey)
                                                        .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void unused) {
                                                        sendNotification(SenderName[0], message.getMessage(), token);

                                                    }
                                                });

                                            }
                                        });
                                    }
                                });
                            }
                        }
                    });
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        String currentId = FirebaseAuth.getInstance().getUid();
        //Toast.makeText(getApplicationContext(), "Resumw Call end", Toast.LENGTH_SHORT).show();
        database.getReference().child("presence").child(currentId).setValue("Online");
        binding.recyclerView.smoothScrollToPosition(binding.recyclerView.getAdapter().getItemCount());
    }



    @Override
    protected void onPause() {
        super.onPause();
        String currentId = FirebaseAuth.getInstance().getUid();
        //Toast.makeText(getApplicationContext(), "Pause Call end", Toast.LENGTH_SHORT).show();
        database.getReference().child("presence").child(currentId).setValue("Offline");

    }

    @Override
    public boolean onSupportNavigateUp()
    {
        finish();
        return super.onSupportNavigateUp();
    }
}