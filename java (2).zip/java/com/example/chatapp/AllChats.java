package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;

import com.example.chatapp.databinding.ActivityAllChatsBinding;
import com.example.chatapp.databinding.ActivityHomeBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class AllChats extends AppCompatActivity {

    ActivityAllChatsBinding binding;
    FirebaseDatabase database;
    ArrayList<User> users;
    UsersAdapter usersAdapter;
    String Char;

    String s1;
    ProgressDialog progressDialog;
    boolean re = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityAllChatsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        progressDialog = new ProgressDialog(AllChats.this);
        progressDialog.setMessage("LOADING....");

        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();


        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

        s1 = sh.getString("Status", "");

        if(s1.equals("Students"))
        {
            Char = "Teachers";
        }
        else
            Char = "Students";

        database = FirebaseDatabase.getInstance();


        users = new ArrayList<>();
        usersAdapter=new UsersAdapter(this, users);
        binding.recyclerView.setAdapter(usersAdapter);
        List<String> uids = new ArrayList<>();
        re = true;

        binding.bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
       /* database.getReference().child("chats").child(FirebaseAuth.getInstance().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snapshot1: snapshot.getChildren()){
                    String key = snapshot1.getKey();
                    uids.add(key);
                    users.clear();
                    database.getReference().child("users").child(Char).child(key).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot2) {

                            if(snapshot2.exists()) {

                                    User user = snapshot2.getValue(User.class);

                                if(!users.contains(user)) {

                                    users.add(user);
                                }


                               // usersAdapter.notifyDataSetChanged();
                                //Collections.reverse(users);

                                usersAdapter.notifyDataSetChanged();
                            }

                            progressDialog.dismiss();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

*/

    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment = null;
            switch (item.getItemId()) {
                case R.id.HomeButton:
                    if(s1.equals("Students"))
                        startActivity(new Intent(AllChats.this, Home.class));
                    else
                        startActivity(new Intent(AllChats.this, TeacherHome.class));

                    //fragment = new openFragment(HomeFragment.newInstance("", ""));
                    return true;
                case R.id.chats:
                    startActivity(new Intent(AllChats.this, AllChats.class));
                    return true;

            }
            //getSupportFragmentManager().beginTransaction().replace(R.id.layout11,fragment).commit();
            return true;
        }
    };




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topmenu, menu);
        MenuItem menuItem1 = menu.findItem(R.id.sortByPriceD);
        menuItem1.setVisible(false);
        MenuItem menuItem2 = menu.findItem(R.id.sortByRatingD);
        menuItem2.setVisible(false);
        MenuItem menuItem3 = menu.findItem(R.id.sortByPriceA);
        menuItem3.setVisible(false);
        MenuItem menuItem4 = menu.findItem(R.id.sortByRatingA);
        menuItem4.setVisible(false);

        MenuItem item=menu.findItem(R.id.search);

        SearchView searchView=(SearchView)item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                processsearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                processsearch(s);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //startActivity(new Intent(AllChats.this, AllChats.class));


        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Online");
        users.clear();
        if (re) {
            database.getReference().child("chats").child(FirebaseAuth.getInstance().getUid()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        String key = snapshot1.getKey();

                        users.clear();
                        database.getReference().child("users").child(Char).child(key).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot2) {

                                if (snapshot2.exists()) {

                                    User user = snapshot2.getValue(User.class);
                                    if (!users.contains(user)) {

                                        users.add(user);
                                    }


                                    // usersAdapter.notifyDataSetChanged();
                                    //Collections.reverse(users);

                                    usersAdapter.notifyDataSetChanged();
                                }

                                //progressDialog.dismiss();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        progressDialog.dismiss();
    }

    @Override
    protected void onPause() {
        super.onPause();
        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Offline");
        users.clear();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        if(menuItem.getItemId() == R.id.SignOut)
        {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(AllChats.this, MainActivity.class));
        }
        else if(menuItem.getItemId() == R.id.sortByPriceA)
        {



        }
        return true;
    }

    private void processsearch(String s)
    {
        s = s.toUpperCase();
        String d =s;



        users.clear();

         database.getReference().child("chats").child(FirebaseAuth.getInstance().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snapshot1: snapshot.getChildren()){
                    String key = snapshot1.getKey();
                    database.getReference().child("users").child(Char).child(key).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot2) {
                          //

                            List<String > U = new ArrayList<>();
                            if(snapshot2.exists()) {
                                User user = snapshot2.getValue(User.class);
                                String names[]=user.getName().toUpperCase().split(" ");
                                String o[] = d.toUpperCase().split(" ");
                                if(o.length <= 1) {
                                    for (int i = 0; i < names.length; i++) {
                                        if (names[i].startsWith(d.toUpperCase())) {
                                            if (!U.contains(user.getUid())) {
                                                users.add(user);
                                                U.add(user.getUid());
                                            }

                                        }
                                    }
                                }
                                else
                                {
                                    if (user.getName().toUpperCase().startsWith(d.toUpperCase())) {
                                        if (!U.contains(user.getUid())) {
                                            users.add(user);
                                            U.add(user.getUid());
                                        }

                                    }

                                }

                                usersAdapter.notifyDataSetChanged();
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


}