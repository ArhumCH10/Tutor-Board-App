package com.example.chatapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.jitsi.meet.sdk.BroadcastEvent;

public class PriceActivity extends AppCompatActivity {

    String name, SenderName;
    String profilePic, token, SenderProfile, SenderToken, MeetingRoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price);

        name = getIntent().getStringExtra("username");
        profilePic = getIntent().getStringExtra("profilePic");
        token = getIntent().getStringExtra("token");
        SenderName = getIntent().getStringExtra("SenderName");
        SenderProfile = getIntent().getStringExtra("SenderProfile");
        SenderToken = getIntent().getStringExtra("SenderToken");
        String senderRoom = getIntent().getStringExtra("SenderRoom");
        String ReceiverUid = getIntent().getStringExtra("ReceiverUid");

        EditText price = findViewById(R.id.Price);
        Button Start = findViewById(R.id.SendRequest);


        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(price.getText().toString().length() > 0)
                {
                    Intent intent =new Intent(getApplicationContext(),OutgoingInvitationActivity.class);
                    intent.putExtra("username",name);
                    intent.putExtra("profilePic",profilePic);
                    intent.putExtra("token",token);
                    intent.putExtra("SenderName",SenderName);
                    intent.putExtra("SenderProfile",SenderProfile);
                    intent.putExtra("SenderToken",SenderToken);
                    intent.putExtra("SenderRoom", senderRoom);
                    intent.putExtra("ReceiverUid", ReceiverUid);
                    intent.putExtra("Price", Integer.parseInt(price.getText().toString()));
                    startActivity(intent);
                    IntentFilter intentFilter = new IntentFilter();
                    intentFilter.addAction(BroadcastEvent.Type.CONFERENCE_JOINED.getAction());
                    finish();

                }
                else
                {
                    price.setError("Price is required");
                    return;
                }
            }
        });

    }
}