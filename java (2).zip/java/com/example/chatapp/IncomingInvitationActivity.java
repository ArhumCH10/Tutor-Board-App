package com.example.chatapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.ActivityIncomingInvitationBinding;
import com.example.chatapp.databinding.ActivityOutgoingInvitationBinding;

import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class IncomingInvitationActivity extends AppCompatActivity {
    ActivityIncomingInvitationBinding binding;
    String ProfilePic, Name, SenderToken, MeetingRoom,ReceiverUid, SenderUid, PaymentId;
    int TotalPayment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIncomingInvitationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Name = getIntent().getStringExtra("SenderName");
        ProfilePic = getIntent().getStringExtra("SenderProfile");
        SenderToken = getIntent().getStringExtra("SenderToken");
        MeetingRoom = getIntent().getStringExtra("MeetingRoom");
        ReceiverUid = getIntent().getStringExtra("ReceiverUid");
        SenderUid = getIntent().getStringExtra("SenderUid");
        PaymentId = getIntent().getStringExtra("PaymentId");
        TotalPayment = getIntent().getIntExtra("TotalPayment", 0);

        binding.textUserName.setText(Name);
        Glide.with(IncomingInvitationActivity.this).load(ProfilePic)
                .placeholder(R.drawable.imageplaceholder)
                .into(binding.PersonWhoCall);


        binding.imageAcceptInvitation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendNotification("accepted");
                Intent intent1 =new Intent(getApplicationContext(),JitsiMeet.class);
                intent1.putExtra("SenderRoom", SenderUid);
                intent1.putExtra("MeetingRoom", MeetingRoom);
                intent1.putExtra("ReceiverUid", ReceiverUid);
                intent1.putExtra("PaymentId", PaymentId);
                intent1.putExtra("TotalPayment", TotalPayment);


                startActivity(intent1);
                finish();
               /* try {
                    JitsiMeetConferenceOptions options = new JitsiMeetConferenceOptions.Builder()
                            .setServerURL(new URL("https://meet.jit.si"))
                            .setRoom(MeetingRoom)
                            .build();
                    JitsiMeetActivity.launch(getApplicationContext(), options);
                    finish();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }*/



            }
        });
        binding.imageRejectInvitation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendNotification("rejected");
                finish();
            }
        });
    }
    void sendNotification(String Response)
    {
        try {
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = "https://fcm.googleapis.com/fcm/send";
            JSONObject data = new JSONObject();
            data.put("title", "Call");
            data.put("body", Response);
            JSONObject notificationdata = new JSONObject();
            notificationdata.put("notification", data);
            notificationdata.put("to", SenderToken);

            JsonObjectRequest request = new JsonObjectRequest(url, notificationdata, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    })
            {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> map = new HashMap<>();
                    String key = "Key=AAAAzHJtcAU:APA91bENpGRgO9da8TIsXMBrLdRyfVyOJHfF9dU9CIUtc4hX6vayv_z25Vt92HUJ94gaKIb8dbRjdkC2dcBsOGJrWP1tjZvGmqMYPt7LqeykMPVLOfmpXZAJmVNAIo8mCzQSQqxzFMq4";

                    map.put("Content-Type", "application/json");
                    map.put("Authorization",key);
                    return map;
                }
            };
            queue.add(request);

        }catch (Exception ex)
        {

        }

    }
    private BroadcastReceiver InvitationResponseReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String Type = intent.getStringExtra("CallResponse");
            if (Type != null) {
                if (Type.equals("cancelled")) {
                    Toast.makeText(getApplicationContext(), "InvitationCancelled", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(
                InvitationResponseReceiver, new IntentFilter("CallResponse")
        );
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(
                InvitationResponseReceiver
        );
    }
}