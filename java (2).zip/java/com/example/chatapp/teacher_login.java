package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class teacher_login extends AppCompatActivity {

    EditText Memail,Mpass;
    Button Mlogin;
    TextView Mcreate;
    FirebaseAuth fAuth;
    FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_login);
        Memail=findViewById(R.id.t_email_login) ;
        Mpass=findViewById(R.id.t_password_login);
        Mlogin=findViewById((R.id.t_login_btn));
        Mcreate=findViewById(R.id.t_signup_btn_login);
        fAuth= FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(teacher_login.this);
        progressDialog.setMessage("LOADING...");
        progressDialog.setTitle("PLEASE WAIT");


        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);


        Mlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email= Memail.getText().toString().trim();
                String password=Mpass.getText().toString().trim();
                if(TextUtils.isEmpty(email))
                {
                    Memail.setError("email is required");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    Mpass.setError("Password is required");
                    return;
                }
                if(password.length()<6)
                {
                    Mpass.setError("password must be more than 5 characters long");
                    return;
                }
                progressDialog.show();
                fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {

                            database.getReference().child("users").child("Teachers").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                        TeacherClass user1 = snapshot1.getValue(TeacherClass.class);


                                        String key = FirebaseAuth.getInstance().getUid();
                                        String k = user1.getUid();

                                        if (k.equals(key)) {
                                            FirebaseUser user = fAuth.getCurrentUser();
                                            if (!user.isEmailVerified()) {
                                                Toast.makeText(teacher_login.this, "Email is not verified", Toast.LENGTH_SHORT).show();
                                                return;
                                            } else {
                                                SharedPreferences sp = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                                                ;
                                                SharedPreferences.Editor myEdit = sp.edit();
                                                myEdit.putString("Status", "Teachers");
                                                myEdit.commit();
                                                progressDialog.dismiss();

                                                Toast.makeText(teacher_login.this, "Logged In", Toast.LENGTH_SHORT).show();
                                                startActivity(new Intent(getApplicationContext(), TeacherHome.class));
                                            }
                                        }

                                    }
                                    Memail.setError("Invalid email");
                                    progressDialog.dismiss();
                                    return;
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });

                        }
                        else {
                            progressDialog.dismiss();
                            Toast.makeText(teacher_login.this, "Error"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });
        Mcreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),teacher_signup.class));
            }
        });
    }
}