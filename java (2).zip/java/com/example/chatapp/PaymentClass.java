package com.example.chatapp;

import java.util.Date;

public class PaymentClass {
    String SenderUid, ReceiverUid,ReceiverName, SenderName, MeetingID, PaymentStatus= "Incomplete";
    int TotalPayment;

    private long DateTime = 0;
    public PaymentClass() {
    }

    public PaymentClass(String SenderUid, String ReceiverUid, String ReceiverName, String SenderName, String MeetingID, int TotalPayment ) {
        this.SenderUid = SenderUid;
        this.ReceiverUid = ReceiverUid;
        this.ReceiverName = ReceiverName;
        this.SenderName = SenderName;
        this.MeetingID = MeetingID;
        this.TotalPayment = TotalPayment;
    }

    public String getSenderUid() {
        return SenderUid;
    }

    public void setSenderUid(String senderUid) {
        SenderUid = senderUid;
    }

    public String getReceiverUid() {
        return ReceiverUid;
    }

    public void setReceiverUid(String receiverUid) {
        ReceiverUid = receiverUid;
    }

    public String getReceiverName() {
        return ReceiverName;
    }

    public void setReceiverName(String receiverName) {
        ReceiverName = receiverName;
    }

    public String getSenderName() {
        return SenderName;
    }

    public void setSenderName(String senderName) {
        SenderName = senderName;
    }

    public String getMeetingID() {
        return MeetingID;
    }

    public void setMeetingID(String meetingID) {
        MeetingID = meetingID;
    }

    public String getPaymentStatus() {
        return PaymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        PaymentStatus = paymentStatus;
    }

    public long getDateTime() {
        return DateTime;
    }

    public void setDateTime(long dateTime) {
        DateTime = dateTime;
    }

    public int getTotalPayment() {
        return TotalPayment;
    }

    public void setTotalPayment(int totalPayment) {
        TotalPayment = totalPayment;
    }
}
