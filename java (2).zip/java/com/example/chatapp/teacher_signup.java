package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Date;
import java.util.HashMap;

public class teacher_signup extends AppCompatActivity {

    public static final String TAG = "TAG";
    EditText Mname,Memail,Mpass,Mage,Mfrom,Mexperiance,Mrate,Mdesc,Meducation, MCourses;
    Button Mreg;
    TextView Mlogin;
    ImageView imageView;
    FirebaseAuth fAuth;
    FirebaseDatabase database;
    FirebaseStorage storage;
    Uri selectedImage;
    ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_signup);
        fAuth = FirebaseAuth.getInstance();
        Mname=findViewById(R.id.name_et_tup);
        Memail=findViewById(R.id.email_et_tup);
        Mpass=findViewById(R.id.password_et_tup);
        Mreg=findViewById(R.id.signup_btn_tup);
        Mlogin=findViewById(R.id.signin_btn_tup);
        Mfrom=findViewById(R.id.from_et_tup);
        Mrate=findViewById(R.id.rate_et_tup);
        Mexperiance=findViewById(R.id.experiance_et_tup);
        Meducation=findViewById(R.id.education_et_tup);
        Mage=findViewById(R.id.age_et_tup);
        Mdesc=findViewById(R.id.description_et_tup);
        MCourses=findViewById(R.id.Courses);
        imageView = findViewById(R.id.imageViewTeacher);
        dialog = new ProgressDialog(this);
        dialog.setMessage("Updating profile...");
        dialog.setCancelable(false);

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        getSupportActionBar().hide();

        fAuth= FirebaseAuth.getInstance();
        final String[] Userid = new String[1];

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, 45);
            }
        });

        Mreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email= Memail.getText().toString().trim();
                String password=Mpass.getText().toString().trim();
                String name=Mname.getText().toString();
                String from=Mfrom.getText().toString();
                String Courses = MCourses.getText().toString();

                float rate= Float.valueOf(Mrate.getText().toString());
                String experiance=Mexperiance.getText().toString();
                String education=Meducation.getText().toString();
                String desc=Mdesc.getText().toString();
                String age=Mage.getText().toString();


                if(TextUtils.isEmpty(email))
                {
                    Memail.setError("email is required");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    Mpass.setError("Password is required");
                    return;
                }
                if(password.length()<6)
                {
                    Mpass.setError("password must be more then 5 characters long");
                    return;
                }
                if(TextUtils.isEmpty(name))
                {
                    Mname.setError("Name is required");
                    return;
                }
                if(TextUtils.isEmpty(age))
                {
                    Mage.setError("Age is required");
                    return;
                }
                if(TextUtils.isEmpty(from))
                {
                    Mage.setError("Fill this field");
                    return;
                }
                if(TextUtils.isEmpty(education))
                {
                    Mage.setError("Education is required");
                    return;
                }
                if(TextUtils.isEmpty(Mrate.getText().toString()))
                {
                    Mrate.setError("Rate is required");
                    return;
                }
                if(TextUtils.isEmpty(desc))
                {
                    Mdesc.setError("Description is required");
                    return;
                }
                if(TextUtils.isEmpty(experiance))
                {
                    Mdesc.setError("Experiance is required");
                    return;
                }
                if(TextUtils.isEmpty(Courses))
                {
                    MCourses.setError("Courses is required");
                    return;
                }
                String CoursesList = Courses.toUpperCase();


                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            FirebaseUser User=fAuth.getCurrentUser();
                            User.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(teacher_signup.this, "Verification Email has been Sent", Toast.LENGTH_SHORT).show();
                                    dialog.show();
                                    if(selectedImage != null) {

                                        FirebaseStorage storage = FirebaseStorage.getInstance();
                                        long time = new Date().getTime();
                                        StorageReference reference = storage.getReference().child("Profiles").child("Teachers").child(fAuth.getUid());
                                        reference.putFile(selectedImage).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                                if(task.isSuccessful()) {
                                                    reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                        @Override
                                                        public void onSuccess(Uri uri) {

                                                        }
                                                    });
                                                }
                                            }
                                        });
                                        reference.putFile(selectedImage).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                                if(task.isSuccessful()) {
                                                    reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                        @Override
                                                        public void onSuccess(Uri uri) {
                                                            String imageUrl = uri.toString();

                                                            String uid = fAuth.getUid();

                                                            TeacherClass user = new TeacherClass(uid,name,imageUrl,from,age,education,email,password,desc,experiance,5, CoursesList);

                                                            database.getReference()
                                                                    .child("users")
                                                                    .child("Teachers")
                                                                    .child(uid)
                                                                    .setValue(user)
                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                        @Override
                                                                        public void onSuccess(Void aVoid) {
                                                                            dialog.dismiss();
                                                                            Intent intent = new Intent(teacher_signup.this, teacher_login.class);
                                                                            intent.putExtra("username", name);
                                                                            startActivity(intent);
                                                                            finish();
                                                                        }
                                                                    });
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    } else {
                                        String uid = fAuth.getUid();

                                        TeacherClass user = new TeacherClass(uid,name,"No Image",from,age,education,email,password,desc,experiance, rate, CoursesList);



                                        database.getReference()
                                                .child("users")
                                                .child("Teachers")
                                                .child(uid)
                                                .setValue(user)
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {
                                                        dialog.dismiss();
                                                        Intent intent = new Intent(teacher_signup.this, Teacher_Signed_In.class);
                                                        intent.putExtra("username", name);
                                                        startActivity(intent);
                                                        finish();
                                                    }
                                                });
                                    }

                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG,"Email not sent"+e.getMessage());
                                }
                            });
                            Toast.makeText(teacher_signup.this, "User Created", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),Teacher_Signed_In.class));
                        }
                        else
                        {
                            Toast.makeText(teacher_signup.this, "Error"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });
        Mlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),teacher_login.class));
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(data != null) {
            if(data.getData() != null) {
                Uri uri = data.getData(); // filepath
                /*FirebaseStorage storage = FirebaseStorage.getInstance();
                long time = new Date().getTime();
                StorageReference reference = storage.getReference().child("Profiles").child("Students").child(fAuth.getUid());
                reference.putFile(uri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful()) {
                            reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String filePath = uri.toString();
                                    HashMap<String, Object> obj = new HashMap<>();
                                    obj.put("profileImage", filePath);
                                    database.getReference().child("users").child("Students")
                                            .child(fAuth.getUid())
                                            .updateChildren(obj).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {

                                        }
                                    });
                                }
                            });
                        }
                    }
                });
*/

                imageView.setImageURI(data.getData());
                selectedImage = data.getData();
            }
        }
    }
}