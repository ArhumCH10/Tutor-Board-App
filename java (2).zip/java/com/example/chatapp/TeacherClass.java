package com.example.chatapp;

public class TeacherClass {
    private String uid, name, profileImage, token, from, age, education, email, password, description, experience,
    Courses;
    private float rating = 0, TotalRating = 0, rate;
    int PersonRate = 0;

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public TeacherClass() {
    }

    public TeacherClass(String uid, String name, String profileImage, String from, String age, String education, String email, String password, String description, String experience, float rate, String couses) {
        this.uid = uid;
        this.name = name;
        this.profileImage = profileImage;
        this.from = from;
        this.age = age;
        this.education = education;
        this.email = email;
        this.password = password;
        this.description = description;
        this.experience = experience;
        this.rate = rate;
        this.Courses = couses ;
    }

    public float getTotalRating() {
        return TotalRating;
    }

    public void setTotalRating(float totalRating) {
        TotalRating = totalRating;
    }

    public int getPersonRate() {
        return PersonRate;
    }

    public void setPersonRate(int personRate) {
        PersonRate = personRate;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getCourses() {
        return Courses;
    }

    public void setCourses(String courses) {
        Courses = courses;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }
}
