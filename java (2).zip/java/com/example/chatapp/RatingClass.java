package com.example.chatapp;

public class RatingClass {

    String SenderName, SenderUid, SenderToken, SenderProfile, comment;
    float Rating;

    public RatingClass(String senderName, String senderUid, String senderToken, String senderProfile, String comment, float rating) {
        SenderName = senderName;
        SenderUid = senderUid;
        SenderToken = senderToken;
        SenderProfile = senderProfile;
        this.comment = comment;
        Rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getSenderName() {
        return SenderName;
    }

    public void setSenderName(String senderName) {
        SenderName = senderName;
    }

    public String getSenderUid() {
        return SenderUid;
    }

    public void setSenderUid(String senderUid) {
        SenderUid = senderUid;
    }

    public String getSenderToken() {
        return SenderToken;
    }

    public void setSenderToken(String senderToken) {
        SenderToken = senderToken;
    }

    public String getSenderProfile() {
        return SenderProfile;
    }

    public void setSenderProfile(String senderProfile) {
        SenderProfile = senderProfile;
    }

    public float getRating() {
        return Rating;
    }

    public void setRating(float rating) {
        Rating = rating;
    }

    public RatingClass() {
    }


}
