package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Student_Signed_In extends AppCompatActivity {

    Button Mlogout,Mverifybtn;
    TextView Mverifymsg;
    FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_signed_in);
        Mlogout=findViewById(R.id.logout_btn_s);
        Mverifymsg=findViewById(R.id.verify_msg_s);
        Mverifybtn=findViewById(R.id.verify_btn_s);
        fAuth=FirebaseAuth.getInstance();
        FirebaseUser user= fAuth.getCurrentUser();
        if(!user.isEmailVerified())
        {
            Mverifymsg.setVisibility(View.VISIBLE);
            Mverifybtn.setVisibility(View.VISIBLE);
            Mverifybtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FirebaseUser User=fAuth.getCurrentUser();
                    User.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(Student_Signed_In.this, "Verification Email has been Sent", Toast.LENGTH_SHORT).show();

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d("tag","Email not sent"+e.getMessage());
                        }
                    });
                }
            });
        }
        Mlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(),student_login.class));
                finish();
            }
        });
    }
}