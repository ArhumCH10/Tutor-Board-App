package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.chatapp.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    Button Student_btn;
    Button Teacher_btn;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Student_btn=findViewById(R.id.student_btn);
        Teacher_btn=findViewById(R.id.teacher_btn);
        auth = FirebaseAuth.getInstance();
        if(auth.getCurrentUser() != null)
        {
            SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

            String s1 = sh.getString("Status", "");


            String name = getIntent().getStringExtra("username");
            if(!s1.equals(" ")) {
                if (s1.equals("Teachers")) {
                    Intent intent = new Intent(MainActivity.this, TeacherHome.class);
                    intent.putExtra("username", name);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(MainActivity.this, Home.class);
                    intent.putExtra("username", name);
                    startActivity(intent);
                }
                finish();
            }


        }
        Student_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),student_login.class));
            }
        });
        Teacher_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),teacher_login.class));
            }
        });
    }
}