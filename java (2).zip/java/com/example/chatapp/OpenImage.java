package com.example.chatapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class OpenImage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_image);
        ImageView img = findViewById(R.id.showImage);
        String imgR = getIntent().getStringExtra("ImageSend");

        Glide.with(this).load(imgR)
                .placeholder(R.drawable.imageplaceholder)
                .into(img);
    }
}