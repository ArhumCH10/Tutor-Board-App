package com.example.chatapp;

import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jitsi.meet.sdk.JitsiMeetViewListener;

import java.util.Date;
import java.util.Map;

public class MyJitsiMeetViewListener implements JitsiMeetViewListener {
    FirebaseDatabase database;
    Context context;
    int MeetingEnd = -1, TotalPayment;
    String SenderRoom, MeetingRoom, ReceiverUid, PaymentId;


    public MyJitsiMeetViewListener(Context context, String SenderRoom,String ReceiverUid, String MeetingRoom, String PaymentId, int TotalPayment) {
        this.context = context;
        this.MeetingRoom=MeetingRoom;
        this.SenderRoom = SenderRoom;
        this.ReceiverUid = ReceiverUid;
        this.PaymentId = PaymentId;
        this.TotalPayment = TotalPayment;
    }


    @Override
    public void onConferenceJoined(Map<String, Object> map) {

    }

    @Override
    public void onConferenceTerminated(Map<String, Object> map) {
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        database = FirebaseDatabase.getInstance();
        database.getReference().child("meetings").child(SenderRoom).child(ReceiverUid).child(MeetingRoom)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                             meeting u = snapshot.getValue(meeting.class);
                             MeetingEnd = u.getMeetingEnd();

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });



        if(MeetingEnd == -1)
        {
            MeetingEnd = 1;
            database = FirebaseDatabase.getInstance();
            database.getReference().child("meetings").child(SenderRoom).child(ReceiverUid).child(MeetingRoom)
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists())
                            {
                                Date date = new Date();

                                meeting u = snapshot.getValue(meeting.class);
                                if(u.getMeetingEnd() != 1) {

                                    u.setEndtimestamp(date.getTime());
                                    u.setMeetingEnd(1);
                                    database.getReference().child("meetings").child(SenderRoom).child(ReceiverUid).child(MeetingRoom).setValue(u);

                                }
                                database.goOffline();
                                database.goOnline();


                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

        }

        Intent intent = new Intent(context, Rating.class);
        intent.putExtra("ReceiverUid", ReceiverUid);
        intent.putExtra("SenderUid", SenderRoom);
        intent.putExtra("MeetingRoom", MeetingRoom);
        intent.putExtra("PaymentId",PaymentId);
        intent.putExtra("TotalPayment",TotalPayment);

        context.startActivity(intent);
        /*Intent intent = new Intent(context, Payment.class);
        intent.putExtra("ReceiverUid", ReceiverUid);
        intent.putExtra("MeetingRoom", MeetingRoom);
        context.startActivity(intent);*/


    }

    @Override
    public void onConferenceWillJoin(Map<String, Object> map) {

    }
}
