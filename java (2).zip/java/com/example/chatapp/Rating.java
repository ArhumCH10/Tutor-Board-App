package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.ActivityOutgoingInvitationBinding;
import com.example.chatapp.databinding.ActivityRatingBinding;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Rating extends AppCompatActivity {
    ActivityRatingBinding binding;
    FirebaseDatabase database;
    private String SenderName;
    private String SenderProfile;
    private String SenderToken;
    private String SenderUid, MeetingRoom, PaymentId;
    private float TotalRating;
    private int TotalCount, TotalPayment ;
    PaymentClass PC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRatingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        database = FirebaseDatabase.getInstance();
        String ReceiverUid;



        MeetingRoom = getIntent().getStringExtra("MeetingRoom");
        PaymentId = getIntent().getStringExtra("PaymentId");
        TotalPayment = getIntent().getIntExtra("TotalPayment", 0);


        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

        String s1 = sh.getString("Status", "");

        SharedPreferences sp = getSharedPreferences("MySharedPref",MODE_PRIVATE);;
        SharedPreferences.Editor myEdit = sp.edit();
        myEdit.putString("PaymentId",PaymentId );
        myEdit.commit();
        String Char;
        if(s1.equals("Students"))
        {
            Char = "Teachers";
            ReceiverUid = getIntent().getStringExtra("SenderUid");
        }
        else {
            Char = "Students";
            ReceiverUid = getIntent().getStringExtra("ReceiverUid");
        }
        /*database.getReference().child("Payments").child(PaymentId)
                .addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            PC = snapshot.getValue(PaymentClass.class);
                            TotalPayment=PC.getTotalPayment();


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });*/

        database.getReference().child("users").child(s1).child(FirebaseAuth.getInstance().getUid())
                .addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            User u = snapshot.getValue(User.class);
                            SenderName = u.getName();
                            SenderProfile = u.getProfileImage();
                            SenderToken = u.getToken();
                            SenderUid = u.getUid();

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
        if(Char.equals("Teachers")) {
            database.getReference().child("users").child(Char).child(ReceiverUid)
                    .addValueEventListener(new ValueEventListener() {

                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                TeacherClass u = snapshot.getValue(TeacherClass.class);
                                TotalRating = u.getTotalRating();
                                TotalCount = u.getPersonRate();

                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


        }
        else {
            database.getReference().child("users").child(Char).child(ReceiverUid)
                    .addValueEventListener(new ValueEventListener() {

                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                StudentClass u = snapshot.getValue(StudentClass.class);
                                TotalRating = u.getTotalRating();
                                TotalCount = u.getPersonRate();

                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


        }

        binding.SubmitReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(binding.ReasonReport.getText().toString().length() < 1)
                {
                    binding.ReasonReport.setError("Please Give Reaon");
                }
                else
                {
                    database = FirebaseDatabase.getInstance();
                    TotalRating = TotalRating + 0;
                    String randomKey = getIntent().getStringExtra("MeetingRoom");
                    RatingClass ratingClass = new RatingClass(SenderName,SenderUid,SenderToken,SenderProfile,binding.ReasonReport.getText().toString(),0);
                    database.getReference().child("Rating").child(Char)
                            .child(ReceiverUid)
                            .child(randomKey)
                            .setValue(ratingClass).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            database.goOffline();
                            database.goOnline();

                            TotalCount = TotalCount+1;
                            SetRatingInUsers(TotalRating, TotalCount,ReceiverUid, Char);
                            if(s1.equals("Teachers")) {

                                Intent intent = new Intent(getApplicationContext(), AllChats.class);
                                startActivity(intent);
                                finish();
                            }

                            else
                            {
                                Intent intent = new Intent(getApplicationContext(), Payment.class);
                                startActivity(intent);
                                finish();
                            }

                        }

                    });


                    Toast.makeText(getApplicationContext(), binding.ReasonReport.getText().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        binding.RatingSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(binding.ReasonRAte.getText().toString().length() < 1)
                {
                    binding.ReasonRAte.setError("Please Give Reaon");
                }
                else
                {
                    database = FirebaseDatabase.getInstance();
                    float s = Float.parseFloat(String.valueOf(binding.RatingScale.getRating()));
                    TotalRating = TotalRating + s;
                    String randomKey = getIntent().getStringExtra("MeetingRoom");
                    RatingClass ratingClass = new RatingClass(SenderName,SenderUid,SenderToken,SenderProfile,binding.ReasonRAte.getText().toString(),s);
                    database.getReference().child("Rating").child(Char)
                            .child(ReceiverUid)
                            .child(randomKey)
                            .setValue(ratingClass).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {

                            database.goOffline();
                            database.goOnline();

                            TotalCount = TotalCount+1;
                            SetRatingInUsers(TotalRating, TotalCount,ReceiverUid, Char);

                            if(s1.equals("Teachers")) {

                                Intent intent = new Intent(getApplicationContext(), AllChats.class);
                                startActivity(intent);
                            }

                            else
                            {

                                Intent intent = new Intent(getApplicationContext(), Payment.class);


                                startActivity(intent);
                            }

                        }
                    });


                    Toast.makeText(getApplicationContext(), binding.ReasonReport.getText().toString(), Toast.LENGTH_SHORT).show();
                }



                Toast.makeText(getApplicationContext(), binding.ReasonReport.getText().toString(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void SetRatingInUsers(float r, int Count, String receiverUid, String aChar)
    {
        HashMap<String, Object> lastMsgObj = new HashMap<>();
        lastMsgObj.put("totalRating", r);
        r=r/Count;
        lastMsgObj.put("rating", r);
        lastMsgObj.put("personRate", Count);



        database.getReference().child("users").child(aChar).child(receiverUid)
                .updateChildren(lastMsgObj);

    }
}