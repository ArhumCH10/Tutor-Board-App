package com.example.chatapp;

import static android.view.View.GONE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;

import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.ActivityShowPaymentDetailBinding;
import com.example.chatapp.databinding.ActivityVisitTutorProfileBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Collections;

public class ShowPaymentDetail extends AppCompatActivity {

    ActivityShowPaymentDetailBinding binding;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityShowPaymentDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        database = FirebaseDatabase.getInstance();
        String uid = getIntent().getStringExtra("uid");
        String name = getIntent().getStringExtra("name");
        String token = getIntent().getStringExtra("token");

        String profilePic = getIntent().getStringExtra("image");
        String MeetingID = getIntent().getStringExtra("meetingId");
        String email = getIntent().getStringExtra("email");
        int amount = getIntent().getIntExtra("amount",0);
        long PaymentTime = getIntent().getLongExtra("paymentTime", 0);
        String status = getIntent().getStringExtra("status");

        Glide.with(ShowPaymentDetail.this).load(profilePic)
                .placeholder(R.drawable.imageplaceholder)
                .into(binding.imageViewHomeTeacher2);

        binding.price2.setText("$"+amount);
        binding.status2.setText(status);
        binding.tname2.setText(name);

        binding.temail2.setText(email);
        if(PaymentTime == 0)
        {
            binding.ptime.setText("NULL");
        }
        else {
            long time = PaymentTime;


            SimpleDateFormat sdf = new SimpleDateFormat(" E dd-MM-yyyy 'at' hh:mm a");
            String date = sdf.format(time) + "";
            String[] d = date.split("at");
            binding.ptime.setText(d[0] + "\n" + d[1]);
        }

        database.getReference().child("meetings").child(FirebaseAuth.getInstance().getUid())
                .child(uid).child(MeetingID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                {
                    meeting u = snapshot.getValue(meeting.class);

                    long time = u.getStarttimestamp();


                    SimpleDateFormat sdf = new SimpleDateFormat(" E dd-MM-yyyy 'at' hh:mm a");
                    String date = sdf.format(time) + "";
                    String[] d = date.split("at");
                    binding.ts.setText(d[0] + "\n" + d[1]);

                    time = u.getEndtimestamp();


                    SimpleDateFormat sdf2 = new SimpleDateFormat(" E dd-MM-yyyy 'at' hh:mm a");
                    String date2 = sdf2.format(time) + "";
                    String[] d2 = date2.split("at");
                    binding.te.setText(d2[0] + "\n" + d2[1]);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}