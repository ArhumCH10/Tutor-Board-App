package com.example.chatapp;

import static android.view.View.GONE;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.RowAllTutorBinding;
import com.example.chatapp.databinding.RowWalletBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class WalletAdapter extends RecyclerView.Adapter<WalletAdapter.WalletViewHolder>{
        Context context;
        ArrayList<PaymentClass> users;
public WalletAdapter( Context context, ArrayList<PaymentClass> users)
        {
        this.context = context;
        this.users = users;
        }

@NonNull
@Override
public WalletAdapter.WalletViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_wallet, parent, false);
        return new WalletAdapter.WalletViewHolder(view);
        }

@Override
public void onBindViewHolder(@NonNull WalletAdapter.WalletViewHolder holder, int position) {

        PaymentClass user = users.get(position);
        String senderId = FirebaseAuth.getInstance().getUid();

        holder.binding.usernameT.setText(user.getSenderName());

        if(user.getPaymentStatus().equals("Incomplete"))
        {
            holder.binding.PaymentTime.setText("NULL");
        }
        else {
            long time = user.getDateTime();


            SimpleDateFormat sdf = new SimpleDateFormat(" E dd-MM-yyyy 'at' hh:mm a");
            String date = sdf.format(time) + "";
            String[] d = date.split("at");
            holder.binding.PaymentTime.setText(d[0] + "\n" + d[1]);
        }
        holder.binding.status.setText(user.getPaymentStatus());
        holder.binding.Price.setText("$"+user.getTotalPayment());

        FirebaseDatabase database;
        database = FirebaseDatabase.getInstance();

        database.getReference().child("users").child("Students").child(user.getSenderUid())
                .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists())
                                {
                                        StudentClass u = snapshot.getValue(StudentClass.class);

                                        Glide.with(context).load(u.getProfileImage())
                                                .placeholder(R.drawable.imageplaceholder)
                                                .into(holder.binding.profileT);
                                }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                });


        holder.itemView.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {

    database.getReference().child("users").child("Students").child(user.getSenderUid())
            .addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists())
                    {
                        StudentClass u = snapshot.getValue(StudentClass.class);

                        Intent intent = new Intent(context, ShowPaymentDetail.class);
                        intent.putExtra("name", user.SenderName);
                        intent.putExtra("image", u.getProfileImage());
                        intent.putExtra("uid", u.getUid());
                        intent.putExtra("token", u.getToken());
                        intent.putExtra("email", u.getEmail());
                        intent.putExtra("paymentTime", user.getDateTime());
                        intent.putExtra("status", user.getPaymentStatus());
                        intent.putExtra("amount", user.getTotalPayment());
                        intent.putExtra("meetingId", user.getMeetingID());
                        context.startActivity(intent);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }
        });

        }

@Override
public int getItemCount() {
        return users.size();
        }

public class WalletViewHolder extends RecyclerView.ViewHolder
{
    @NonNull RowWalletBinding binding;
    public WalletViewHolder(@NonNull View itemView)
    {
        super(itemView);
        binding = RowWalletBinding.bind(itemView);
    }
}


}

