package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.ActivityHomeBinding;
import com.example.chatapp.databinding.ActivityVisitTutorProfileBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.HashMap;

public class VisitTutorProfile extends AppCompatActivity {
    ActivityVisitTutorProfileBinding binding;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityVisitTutorProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        database = FirebaseDatabase.getInstance();
        String uid = getIntent().getStringExtra("uid");
        String n2 = getIntent().getStringExtra("username");
        String name = getIntent().getStringExtra("name");
        String token = getIntent().getStringExtra("token");

        String profilePic = getIntent().getStringExtra("image");

        binding.chatTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChatActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("image", profilePic);
                intent.putExtra("uid", uid);
                intent.putExtra("token", token);
                startActivity(intent);
            }
        });

        binding.ShowTutorRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ShowRating.class);
                intent.putExtra("ReceiverUid", uid);

                startActivity(intent);

            }
        });
        database.getReference().child("users").child("Teachers")
                .child(uid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            //Toast.makeText(getApplicationContext(), "kkkjhhj", Toast.LENGTH_SHORT).show();
                            TeacherClass u = snapshot.getValue(TeacherClass.class);
                            binding.tname2.setText(u.getName());
                            binding.tage2.setText(u.getAge());
                            binding.temail2.setText(u.getEmail());
                            binding.tdesc2.setText(u.getDescription());
                            binding.tedu2.setText(u.getEducation());
                            binding.texp2.setText(u.getExperience());
                            binding.tloc2.setText(u.getFrom());
                            binding.ratingHT2.setRating(u.getRating());
                            binding.tcourses2.setText(u.getCourses());
                            binding.trate2.setText(u.getRate()+"");
                            Glide.with(VisitTutorProfile.this).load(u.getProfileImage())
                                    .placeholder(R.drawable.imageplaceholder)
                                    .into(binding.imageViewHomeTeacher2);

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        //Toast.makeText(getApplicationContext(), error+"jhhj", Toast.LENGTH_SHORT).show();

                    }
                });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topmenu, menu);

        MenuItem menuItem = menu.findItem(R.id.search);
        menuItem.setVisible(false);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    protected void onResume() {
        super.onResume();
        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Online");
    }

    @Override
    protected void onPause() {
        super.onPause();
        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Offline");

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        Menu menu;
        //menuItem.setVisible(false);
        if(menuItem.getItemId() == R.id.SignOut)
        {
            SharedPreferences sp = getSharedPreferences("MySharedPref",MODE_PRIVATE);;
            SharedPreferences.Editor myEdit = sp.edit();
            myEdit.putString("Status", " ");
            myEdit.commit();
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(VisitTutorProfile.this, MainActivity.class));
        }

        else if(menuItem.getItemId() == R.id.search)
        {
            //getMenuInflater().inflate(R.menu.);
            SearchView searchView = (SearchView) menuItem.getActionView();
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    processearch(query);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    processearch(newText);
                    return false;
                }
            });

        }
        return true;
    }

    private void processearch(String newText) {
        Toast.makeText(getApplicationContext(),"newText",Toast.LENGTH_SHORT).show();

    }


}