package com.example.chatapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.RowAllRatingBinding;
import com.example.chatapp.databinding.RowAllTutorBinding;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class RatingAdapter extends RecyclerView.Adapter<RatingAdapter.RatingViewHolder>{
    Context context;
    ArrayList<RatingClass> users;
    public RatingAdapter( Context context, ArrayList<RatingClass> users)
    {
        this.context = context;
        this.users = users;
    }

    @NonNull
    @Override
    public RatingAdapter.RatingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_all_rating, parent, false);
        return new RatingAdapter.RatingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RatingAdapter.RatingViewHolder holder, int position) {

        RatingClass user = users.get(position);
        String senderId = FirebaseAuth.getInstance().getUid();

        holder.binding.usernameT.setText(user.getSenderName());

        holder.binding.Comment.setText(user.comment);
        holder.binding.ratingHT.setRating(user.getRating());

        Glide.with(context).load(user.getSenderProfile())
                .placeholder(R.drawable.avatar)
                .into(holder.binding.profileT);

    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class RatingViewHolder extends RecyclerView.ViewHolder
    {
        RowAllRatingBinding binding;
        public RatingViewHolder(@NonNull View itemView)
        {
            super(itemView);
            binding = RowAllRatingBinding.bind(itemView);
        }
    }


}
