package com.example.chatapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;
import java.util.HashMap;


public class PaymentComplete extends AppCompatActivity {
    FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_complete);
        database= FirebaseDatabase.getInstance();

        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

        String PaymentId = sh.getString("PaymentId", "");

        HashMap<String, Object> lastMsgObj = new HashMap<>();
        lastMsgObj.put("paymentStatus", "Completed");
        Date date = new Date();
        lastMsgObj.put("dateTime", date.getTime());



        database.getReference().child("Payments").child(PaymentId)
                .updateChildren(lastMsgObj);

        SharedPreferences sp = getSharedPreferences("MySharedPref",MODE_PRIVATE);;
        SharedPreferences.Editor myEdit = sp.edit();
        myEdit.putString("PaymentId","" );
        myEdit.commit();


        Toast.makeText(this,"payment successfull", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(getApplicationContext(), AllChats.class);
        startActivity(intent);
        finish();
    }
}