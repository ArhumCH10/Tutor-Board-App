package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.example.chatapp.databinding.ActivityHomeBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.HashMap;

public class Home extends AppCompatActivity {

    ActivityHomeBinding binding;
    FirebaseDatabase database;
    ArrayList<User> users;
    ProgressDialog progressDialog;
    UsersAdapter usersAdapter;


    ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database = FirebaseDatabase.getInstance();

        progressDialog = new ProgressDialog(Home.this);
        progressDialog.setMessage("LOADING...");
        progressDialog.setTitle("PLEASE WAIT");


        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();

        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(new OnSuccessListener<String>() {
                    @Override
                    public void onSuccess(String s) {
                        HashMap<String , Object> map = new HashMap<>();
                        map.put("token", s);
                        database.getReference().child("users").child("Students")
                                .child(FirebaseAuth.getInstance().getUid())
                                .updateChildren(map);
                    }
                });

        binding.bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        binding.FindTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this, ShowAllTutors.class));

            }
        });

        database.getReference().child("users").child("Students").child(FirebaseAuth.getInstance().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            StudentClass u = snapshot.getValue(StudentClass.class);
                            binding.sname.setText(u.getName());
                            binding.sage.setText(u.getAge());
                            binding.semail.setText(u.getEmail());
                            binding.sdesc.setText(u.getDescription());
                            binding.sedu.setText(u.getEducation());
                            binding.sinst.setText(u.getInstitute());
                            binding.sloc.setText(u.getFrom());
                            binding.ratingHS.setRating(u.getRating());

                            Glide.with(Home.this).load(u.getProfileImage())
                                    .placeholder(R.drawable.imageplaceholder)
                                    .into(binding.imageViewHomeStudent);
                            progressDialog.dismiss();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment = null;
            switch (item.getItemId()) {
                case R.id.HomeButton:

                    //fragment = new openFragment(HomeFragment.newInstance("", ""));
                    return true;
                case R.id.chats:
                    startActivity(new Intent(Home.this, AllChats.class));
                    return true;

            }
            //getSupportFragmentManager().beginTransaction().replace(R.id.layout11,fragment).commit();
            return true;
        }
    };



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topmenu, menu);

        MenuItem menuItem = menu.findItem(R.id.search);
        menuItem.setVisible(false);
        MenuItem menuItem1 = menu.findItem(R.id.sortByPriceD);
        menuItem1.setVisible(false);
        MenuItem menuItem2 = menu.findItem(R.id.sortByRatingD);
        menuItem2.setVisible(false);
        MenuItem menuItem3 = menu.findItem(R.id.sortByPriceA);
        menuItem3.setVisible(false);
        MenuItem menuItem4 = menu.findItem(R.id.sortByRatingA);
        menuItem4.setVisible(false);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    protected void onResume() {
        super.onResume();
        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Online");
    }

    @Override
    protected void onPause() {
        super.onPause();
        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Offline");

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        Menu menu;
        //menuItem.setVisible(false);
        if(menuItem.getItemId() == R.id.SignOut)
        {
            SharedPreferences sp = getSharedPreferences("MySharedPref",MODE_PRIVATE);;
            SharedPreferences.Editor myEdit = sp.edit();
            myEdit.putString("Status", " ");
            myEdit.commit();
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(Home.this, MainActivity.class));
            finish();

        }

        else if(menuItem.getItemId() == R.id.search)
        {
            //getMenuInflater().inflate(R.menu.);
            SearchView searchView = (SearchView) menuItem.getActionView();
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    processearch(query);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    processearch(newText);
                    return false;
                }
            });

        }
        return true;
    }

    private void processearch(String newText) {
        Toast.makeText(getApplicationContext(),"newText",Toast.LENGTH_SHORT).show();

    }


}