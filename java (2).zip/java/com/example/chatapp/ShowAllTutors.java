package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;

import com.example.chatapp.databinding.ActivityShowAllTutorsBinding;
import com.example.chatapp.databinding.ActivityTeacherHomeBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

public class ShowAllTutors extends AppCompatActivity {

    ActivityShowAllTutorsBinding binding;
    FirebaseDatabase database;
    ArrayList<TeacherClass> users;
    TutorAdapter usersAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityShowAllTutorsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database = FirebaseDatabase.getInstance();
        users = new ArrayList<>();
        usersAdapter=new TutorAdapter(this, users);
        binding.recyclerViewTutor.setAdapter(usersAdapter);

        database.getReference().child("users").child("Teachers").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                users.clear();
                for(DataSnapshot snapshot1: snapshot.getChildren()){
                    TeacherClass user = snapshot1.getValue(TeacherClass.class);
                    users.add(user);

                }
                usersAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topmenu, menu);


        MenuItem item=menu.findItem(R.id.search);

        SearchView searchView=(SearchView)item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                processsearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                processsearch(s);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Online");
    }

    @Override
    protected void onPause() {
        super.onPause();
        String currentId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currentId).setValue("Offline");

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        if(menuItem.getItemId() == R.id.SignOut)
        {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(ShowAllTutors.this, MainActivity.class));
        }
        else if(menuItem.getItemId() == R.id.sortByPriceD)
        {
            database.getReference().child("users").child("Teachers").orderByChild("rate").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    users.clear();
                    for(DataSnapshot snapshot1: snapshot.getChildren())
                    {
                        TeacherClass user = snapshot1.getValue(TeacherClass.class);
                        users.add(user);

                    }
                    Collections.reverse(users);
                    usersAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }
        else if(menuItem.getItemId() == R.id.sortByPriceA)
        {
            database.getReference().child("users").child("Teachers").orderByChild("rate").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    users.clear();
                    for(DataSnapshot snapshot1: snapshot.getChildren())
                    {
                        TeacherClass user = snapshot1.getValue(TeacherClass.class);
                        users.add(user);

                    }

                    usersAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }
        else if(menuItem.getItemId() == R.id.sortByRatingA)
        {
            database.getReference().child("users").child("Teachers").orderByChild("rating").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    users.clear();
                    for(DataSnapshot snapshot1: snapshot.getChildren())
                    {
                        TeacherClass user = snapshot1.getValue(TeacherClass.class);
                        users.add(user);

                    }

                    usersAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }
        else if(menuItem.getItemId() == R.id.sortByRatingD)
        {
            database.getReference().child("users").child("Teachers").orderByChild("rating").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    users.clear();
                    for(DataSnapshot snapshot1: snapshot.getChildren())
                    {
                        TeacherClass user = snapshot1.getValue(TeacherClass.class);
                        users.add(user);

                    }
                    Collections.reverse(users);

                    usersAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }
        else if(menuItem.getItemId() == R.id.search)
        {

            SearchView searchView=(SearchView)menuItem.getActionView();

            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String s) {
                    processsearch(s);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    processsearch(s);
                    return false;
                }
            });

        }
        return true;
    }

    private void processsearch(String s)
    {
        s = s.toUpperCase();
        String d =s;

        database.getReference().child("users").child("Teachers").orderByChild("courses").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                users.clear();
                for(DataSnapshot snapshot1: snapshot.getChildren())
                {
                    ArrayList<String> a = new ArrayList<>();
                    TeacherClass user = snapshot1.getValue(TeacherClass.class);
                    String course[] = user.getCourses().split("\n");
                    for(int i = 0;i<course.length;i++)
                    {
                        if (course[i].indexOf(d) > -1)
                        {
                            if(!a.contains(user.getUid())) {
                                users.add(user);
                                a.add(user.getUid());
                            }
                        }
                    }

                }
                usersAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

}