package com.example.chatapp;

public class meeting {
    private String SenderId, ReceiverId, meetingId;
    private long Starttimestamp;
    private long Endtimestamp;
    private int MeetingEnd = -1;

    public String getSenderId() {
        return SenderId;
    }

    public meeting() {
    }

    public meeting(String senderId, String receiverId, String meetingId, long starttimestamp, long endtimestamp) {
        SenderId = senderId;
        ReceiverId = receiverId;
        this.meetingId = meetingId;
        Starttimestamp = starttimestamp;
        Endtimestamp = endtimestamp;


    }

    public String getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(String meetingId) {
        this.meetingId = meetingId;
    }

    public void setSenderId(String senderId) {
        SenderId = senderId;
    }

    public String getReceiverId() {
        return ReceiverId;
    }

    public void setReceiverId(String receiverId) {
        ReceiverId = receiverId;
    }

    public long getStarttimestamp() {
        return Starttimestamp;
    }

    public void setStarttimestamp(long starttimestamp) {
        Starttimestamp = starttimestamp;
    }

    public long getEndtimestamp() {
        return Endtimestamp;
    }

    public void setEndtimestamp(long endtimestamp) {
        Endtimestamp = endtimestamp;
    }

    public int getMeetingEnd() {
        return MeetingEnd;
    }

    public void setMeetingEnd(int meetingEnd) {
        MeetingEnd = meetingEnd;
    }
}
