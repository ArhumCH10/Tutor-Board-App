package com.example.chatapp;

import androidx.lifecycle.LifecycleOwner;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.ObservableSnapshotArray;

public class FirebaseAdaptor extends FirebaseRecyclerAdapter {
    public FirebaseAdaptor(ObservableSnapshotArray observableSnapshotArray, int modelLayout, Class viewHolderClass, LifecycleOwner owner) {
        super(observableSnapshotArray, modelLayout, viewHolderClass, owner);
    }

    @Override
    protected void populateViewHolder(RecyclerView.ViewHolder viewHolder, Object o, int i) {

    }
}
