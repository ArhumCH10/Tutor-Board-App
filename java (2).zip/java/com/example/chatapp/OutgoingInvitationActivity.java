package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.ActivityChatBinding;
import com.example.chatapp.databinding.ActivityOutgoingInvitationBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;

import org.jitsi.meet.sdk.BroadcastEvent;
import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class OutgoingInvitationActivity extends AppCompatActivity {
    ActivityOutgoingInvitationBinding binding;
    public PreferenceManager preferenceManager;
    private String invitation = null;
    String name, SenderName;
    String profilePic, token, SenderProfile, SenderToken, MeetingRoom, PaymentId;
    int Price;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOutgoingInvitationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        try {
            JitsiMeetConferenceOptions options = new JitsiMeetConferenceOptions.Builder()
                    .setServerURL(new URL(""))
                    .build();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        database = FirebaseDatabase.getInstance();

        name = getIntent().getStringExtra("username");
        profilePic = getIntent().getStringExtra("profilePic");
        token = getIntent().getStringExtra("token");
        SenderName = getIntent().getStringExtra("SenderName");
        SenderProfile = getIntent().getStringExtra("SenderProfile");
        SenderToken = getIntent().getStringExtra("SenderToken");
        Price = getIntent().getIntExtra("Price", 0);

        sendNotification(SenderName, SenderProfile, token, SenderToken);
        binding.textUserName.setText(name);
        Glide.with(OutgoingInvitationActivity.this).load(profilePic)
                .placeholder(R.drawable.imageplaceholder)
                .into(binding.CalledPerson);
        binding.imageStopInvitation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CancelInvitation(token);
                finish();
            }
        });
    }

    void sendNotification(String name, String profilePic, String token, String SenderToken) {
        try {
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = "https://fcm.googleapis.com/fcm/send";
            JSONObject data = new JSONObject();
            data.put("title", "Call");
            String randomKey = database.getReference().push().getKey();
            MeetingRoom = randomKey ;
            PaymentId = database.getReference().push().getKey();
            String message = name +" wants to start meeting at "+Price+"$" + "\n" + profilePic +"\n" + SenderToken +"\n" + MeetingRoom + "\n"+getIntent().getStringExtra("ReceiverUid")
                    +"\n"+getIntent().getStringExtra("SenderRoom")+"\n"+PaymentId + "\n"+Price;
            data.put("body", message);
            JSONObject notificationdata = new JSONObject();
            notificationdata.put("notification", data);
            notificationdata.put("to", token);

            JsonObjectRequest request = new JsonObjectRequest(url, notificationdata, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> map = new HashMap<>();
                    String key = "Key=AAAAzHJtcAU:APA91bENpGRgO9da8TIsXMBrLdRyfVyOJHfF9dU9CIUtc4hX6vayv_z25Vt92HUJ94gaKIb8dbRjdkC2dcBsOGJrWP1tjZvGmqMYPt7LqeykMPVLOfmpXZAJmVNAIo8mCzQSQqxzFMq4";

                    map.put("Content-Type", "application/json");
                    map.put("Authorization", key);
                    return map;
                }
            };
            queue.add(request);

        } catch (Exception ex) {

        }

    }
    void CancelInvitation(String token)
    {
        try {
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = "https://fcm.googleapis.com/fcm/send";
            JSONObject data = new JSONObject();
            data.put("title", "Call");
            data.put("body", "cancelled");
            JSONObject notificationdata = new JSONObject();
            notificationdata.put("notification", data);
            notificationdata.put("to", token);

            JsonObjectRequest request = new JsonObjectRequest(url, notificationdata, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    })
            {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> map = new HashMap<>();
                    String key = "Key=AAAAzHJtcAU:APA91bENpGRgO9da8TIsXMBrLdRyfVyOJHfF9dU9CIUtc4hX6vayv_z25Vt92HUJ94gaKIb8dbRjdkC2dcBsOGJrWP1tjZvGmqMYPt7LqeykMPVLOfmpXZAJmVNAIo8mCzQSQqxzFMq4";

                    map.put("Content-Type", "application/json");
                    map.put("Authorization",key);
                    return map;
                }
            };
            queue.add(request);

        }catch (Exception ex)
        {

        }

    }

    private BroadcastReceiver InvitationResponseReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String Type = intent.getStringExtra("CallResponse");
            if (Type != null) {
                if (Type.equals("accepted")) {

                        //String randomKey = database.getReference().push().getKey();
                        Date date = new Date();
                        meeting call = new meeting(SenderToken,token,MeetingRoom,date.getTime(),date.getTime());
                        String senderRoom = getIntent().getStringExtra("SenderRoom");
                        String ReceiverUid = getIntent().getStringExtra("ReceiverUid");
                        database.getReference().child("meetings")
                                .child(senderRoom).child(ReceiverUid)
                                .child(MeetingRoom)
                                .setValue(call).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {

                            }
                        });
                        PaymentClass PC = new PaymentClass(ReceiverUid, senderRoom, SenderName,name, MeetingRoom,Price);

                        database.getReference().child("Payments").child(PaymentId).setValue(PC)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {

                                    }
                                });
                        Intent intent1 =new Intent(getApplicationContext(),JitsiMeet.class);
                        intent1.putExtra("SenderRoom", senderRoom);
                        intent1.putExtra("MeetingRoom", MeetingRoom);
                        intent1.putExtra("ReceiverUid", ReceiverUid);
                        intent1.putExtra("PaymentId", PaymentId);
                        intent1.putExtra("TotalPayment", Price);

                        startActivity(intent1);
                        finish();

                    //jitsi.onCreate();
                } else {
                    Toast.makeText(getApplicationContext(), "Inivation Rejected", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(
                InvitationResponseReceiver, new IntentFilter("CallResponse")
        );
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(
                InvitationResponseReceiver
        );
    }
}