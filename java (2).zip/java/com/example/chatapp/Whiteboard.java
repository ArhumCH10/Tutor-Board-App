package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;
import android.widget.ZoomControls;

import com.google.firebase.auth.FirebaseAuth;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import me.panavtec.drawableview.DrawableView;
import me.panavtec.drawableview.DrawableViewConfig;
import top.defaults.colorpicker.ColorPickerPopup;

public class Whiteboard extends AppCompatActivity {
    DrawableView drawableView;
    Button ZoomIn;
    Button ZoomOut;
    Button color;
    Button undo;
    ZoomControls ZoomScreen;
    DrawableViewConfig config;
    int mDefaultColor = 0;
    String FolderName= "ScreenshotFolder";
    static int counter=1;

    private static final int PERMISSION_REQUEST_CODE = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whiteboard);
        drawableView = (DrawableView)findViewById(R.id.paintview);

        if(ContextCompat.checkSelfPermission ( Whiteboard.this, Manifest.permission.WRITE_EXTERNAL_STORAGE )== PackageManager.PERMISSION_GRANTED  && ContextCompat.checkSelfPermission ( Whiteboard.this, Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
        {
            createDirectory(FolderName);
        }
        else
        {
            askPermission();
        }

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder ();
        StrictMode.setVmPolicy ( builder.build () );


        /*ZoomIn = (Button) findViewById(R.id.zoomin);
        ZoomOut = (Button) findViewById(R.id.zoomout);

        undo = (Button) findViewById(R.id.undo);
        color = (Button) findViewById(R.id.color);*/

        DisplayMetrics DM = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(DM);
        int windowWidth = DM.widthPixels;
        int windowHeight = DM.heightPixels;


        config = new DrawableViewConfig();
        config.setStrokeColor(getResources().getColor(android.R.color.black));
        config.setShowCanvasBounds(true);
        config.setMinZoom(1.0f);
        config.setMaxZoom(3.0f);
        config.setCanvasHeight(windowHeight);
        config.setCanvasWidth(windowWidth);
        drawableView.setConfig(config);


/*        ZoomIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                config.setStrokeWidth(config.getStrokeWidth() + 5);
            }
        });

        ZoomOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(config.getStrokeWidth() >= 5)
                    config.setStrokeWidth(config.getStrokeWidth() - 5);
            }
        });
        color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ColorPickerPopup.Builder(Whiteboard.this).initialColor(Color.RED)
                        .enableBrightness(true) // enable color brightness
                        // slider or not
                        .enableAlpha(true) // enable color alpha
                        // changer on slider or
                        // not
                        .okTitle("Choose") // this is top right
                        // Choose button
                        .cancelTitle("Cancel") // this is top left
                        // Cancel button which
                        // closes the
                        .showIndicator(true) // this is the small box
                        // which shows the chosen
                        // color by user at the
                        // bottom of the cancel
                        // button
                        .showValue(true)
                        .build()
                        .show(
                                v,
                                new ColorPickerPopup.ColorPickerObserver() {
                                    @Override
                                    public void
                                    onColorPicked(int color) {
                                        mDefaultColor = color;
                                        config.setStrokeColor(mDefaultColor);

                                    }
                                });
            }
        });



        undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawableView.undo();
            }
        });
*/

    }

    public void ScreenshotButton()
    {
        View view1 = getWindow ().getDecorView ().getRootView ();
        view1.setDrawingCacheEnabled ( true );
        Bitmap bitmap = Bitmap.createBitmap ( view1.getDrawingCache () );
        view1.setDrawingCacheEnabled ( false );

        // String filePath = Environment.getExternalStorageDirectory () + "/"+FolderName +"/"+ Calendar.getInstance ().getTime ().toString () + ".jpg";
        String filePath = Environment.getExternalStorageDirectory () + "/"+FolderName +"/"+ String.valueOf ( counter )+ ".jpg";
        File fileScreenshot = new File ( filePath );

        FileOutputStream fileOutputStream = null;

        try {
            fileOutputStream = new FileOutputStream ( fileScreenshot );
            bitmap.compress ( Bitmap.CompressFormat.JPEG,100,fileOutputStream );
            fileOutputStream.flush ();
            fileOutputStream.close ();

        } catch (Exception e) {
            e.printStackTrace ();
        }
        counter++;
        /*Intent intent = new Intent (Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile ( fileScreenshot );
        intent.setDataAndType ( uri,"image/jpeg" );
        intent.addFlags ( Intent.FLAG_ACTIVITY_NEW_TASK );
        this.startActivity ( intent );*/
    }

    public void PdfButton()
    {

        //String directory = Environment.getExternalStorageDirectory ()+ "/"+FolderName +"/";
        int counter2=1;
        String file;
        PdfDocument pdfDocument = new PdfDocument();
        int width = 0, height = 0;


        for(int i=0;i<counter-1;i++)
        {
            file = Environment.getExternalStorageDirectory () + "/"+FolderName +"/"+ String.valueOf ( counter2 )+ ".jpg";
            Bitmap bitmap = BitmapFactory.decodeFile(file);
            width = bitmap.getWidth();
            height = bitmap.getHeight();
            PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder ( width, height, 1 ).create ();
            PdfDocument.Page page = pdfDocument.startPage ( myPageInfo );
            page.getCanvas ().drawBitmap ( bitmap, 0, 0, null );
            pdfDocument.finishPage ( page );
            counter2++;
        }

        String pdfFile = Environment.getExternalStorageDirectory () + "/"+FolderName +"/" + "/MyPdfFile.pdf";
        File myPDFFile = new File(pdfFile);


        try {
            pdfDocument.writeTo(new FileOutputStream (myPDFFile));
            Toast.makeText(getApplicationContext(),"pdf created",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"pdf not created",Toast.LENGTH_SHORT).show();
        }

        pdfDocument.close();
    }
    private void askPermission() {

        ActivityCompat.requestPermissions ( this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE},PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == PERMISSION_REQUEST_CODE)
        {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                createDirectory(FolderName);
            }
            else
            {
                Toast.makeText ( Whiteboard.this, "Permission Denied", Toast.LENGTH_SHORT ).show ();
            }
        }
        super.onRequestPermissionsResult ( requestCode, permissions, grantResults );
    }
    private void createDirectory(String folderName)
    {
        File file = new File ( Environment.getExternalStorageDirectory (),folderName );

        if(!file.exists ())
        {
            file.mkdir ();
            Toast.makeText ( Whiteboard.this, "Folder created successfully", Toast.LENGTH_SHORT ).show ();
        }
        else
        {
            Toast.makeText ( Whiteboard.this, "Folder already exists", Toast.LENGTH_SHORT ).show ();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.whiteboardmenu, menu);


        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        Menu menu;
        //menuItem.setVisible(false);
        if(menuItem.getItemId() == R.id.zoomin)
        {
            config.setStrokeWidth(config.getStrokeWidth() + 5);

        }

        else if(menuItem.getItemId() == R.id.zoomout)
        {

            if(config.getStrokeWidth() >= 5)
                config.setStrokeWidth(config.getStrokeWidth() - 5);

        }
        else if(menuItem.getItemId() == R.id.color) {
            View v = null;

                new ColorPickerPopup.Builder(Whiteboard.this).initialColor(Color.RED)
                        .enableBrightness(true) // enable color brightness
                        // slider or not
                        .enableAlpha(true) // enable color alpha
                        // changer on slider or
                        // not
                        .okTitle("Choose") // this is top right
                        // Choose button
                        .cancelTitle("Cancel") // this is top left
                        // Cancel button which
                        // closes the
                        .showIndicator(true) // this is the small box
                        // which shows the chosen
                        // color by user at the
                        // bottom of the cancel
                        // button
                        .showValue(true)
                        .build()
                        .show(
                                v,
                                new ColorPickerPopup.ColorPickerObserver() {
                                    @Override
                                    public void
                                    onColorPicked(int color) {
                                        mDefaultColor = color;
                                        config.setStrokeColor(mDefaultColor);

                                    }
                                });
            }

        else if(menuItem.getItemId() == R.id.undo) {
            drawableView.undo();
        }

        else if(menuItem.getItemId() == R.id.PDF) {
            PdfButton();
        }
        else if(menuItem.getItemId() == R.id.SS) {
            ScreenshotButton();
        }

        return true;
    }


}

