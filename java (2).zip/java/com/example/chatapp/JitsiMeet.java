package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Toolbar;

import com.facebook.react.modules.core.PermissionListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;

import org.jitsi.meet.sdk.JitsiMeetActivityDelegate;
import org.jitsi.meet.sdk.JitsiMeetActivityInterface;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import org.jitsi.meet.sdk.JitsiMeetView;
import org.jitsi.meet.sdk.JitsiMeetViewListener;

import java.net.MalformedURLException;
import java.net.URL;

public class JitsiMeet extends FragmentActivity implements JitsiMeetActivityInterface {
    private JitsiMeetView view;
    FirebaseDatabase database;
    String MeetingRoom, SenderRoom, ReceiverUid, PaymentId;
    int TotalPayment;
    MyJitsiMeetViewListener listener;
    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        JitsiMeetActivityDelegate.onActivityResult(
                this, requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), Whiteboard.class);
        startActivity(intent);
        //Toast.makeText(getApplicationContext(), "Back End Bro", Toast.LENGTH_SHORT).show();
        //JitsiMeetActivityDelegate.onBackPressed();
    }

    @Override
    protected void onUserLeaveHint() {
        Toast.makeText(getApplicationContext(), "User lea End Bro", Toast.LENGTH_SHORT).show();

        super.onUserLeaveHint();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MeetingRoom = getIntent().getStringExtra("MeetingRoom");
        SenderRoom = getIntent().getStringExtra("SenderRoom");
        ReceiverUid = getIntent().getStringExtra("ReceiverUid");
        PaymentId = getIntent().getStringExtra("PaymentId");
        TotalPayment = getIntent().getIntExtra("TotalPayment", 0);


        view = new JitsiMeetView(this);
        JitsiMeetConferenceOptions options = null;
        try {
            options = new JitsiMeetConferenceOptions.Builder()
                    .setServerURL(new URL("https://meet.jit.si"))
                    .setRoom(MeetingRoom)

                    .build();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        view.join(options);
        listener = new MyJitsiMeetViewListener(this, SenderRoom, ReceiverUid, MeetingRoom,PaymentId,TotalPayment);
        view.setListener(listener);

        setContentView(view);
    }



    @Override
    public boolean onPictureInPictureRequested() {
        return super.onPictureInPictureRequested();
    }

    @Override
    protected void onDestroy() {
        ;

        super.onDestroy();



        view.dispose();
        view = null;


        JitsiMeetActivityDelegate.onHostDestroy(this);
        finish();
    }




    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        JitsiMeetActivityDelegate.onNewIntent(intent);
    }

    @Override
    public void onRequestPermissionsResult(
            final int requestCode,
            final String[] permissions,
            final int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        JitsiMeetActivityDelegate.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    @Override
    protected void onResume() {
        super.onResume();
        // Toast.makeText(getApplicationContext(), "Meeting Re End Bro", Toast.LENGTH_SHORT).show();

        JitsiMeetActivityDelegate.onHostResume(this);
    }

    @Override
    protected void onStop() {
        super.onStop();

        Toast.makeText(getApplicationContext(), "Meeting St End Bro", Toast.LENGTH_SHORT).show();

        JitsiMeetActivityDelegate.onHostPause(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "Meeting Pau End Bro", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void requestPermissions(String[] strings, int i, PermissionListener permissionListener) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}