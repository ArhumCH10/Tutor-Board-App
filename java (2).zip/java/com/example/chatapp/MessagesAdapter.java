package com.example.chatapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.chatapp.databinding.ItemReceiveBinding;
import com.example.chatapp.databinding.ItemSendBinding;
import com.github.pgreze.reactions.ReactionPopup;
import com.github.pgreze.reactions.ReactionsConfig;
import com.github.pgreze.reactions.ReactionsConfigBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MessagesAdapter extends RecyclerView.Adapter {

    Context context;
    ArrayList<Message> messages;

    final int ITEM_SENT = 1;
    final int ITEM_RECEIVE = 2;

    String senderRoom;
    String receiveRoom;
    public MessagesAdapter(Context context, ArrayList<Message> messages, String senderRoom, String receiveRoom)
    {
        this.senderRoom = senderRoom;
        this.receiveRoom = receiveRoom;
        this.context = context;
        this.messages = messages;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType == ITEM_SENT)
        {
            View view = LayoutInflater.from(context).inflate(R.layout.item_send, parent, false);
            return new SentViewHolder(view);
        }
        else
        {
            View view = LayoutInflater.from(context).inflate(R.layout.item_receive, parent, false);
            return new ReceiverViewHolder(view);
        }
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messages.get(position);
        if(FirebaseAuth.getInstance().getUid().equals(message.getSenderId()))
        {
            return ITEM_SENT;
        }
        else
            return ITEM_RECEIVE;

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        Message message = messages.get(position);
        int reactions[] = new int[]{
                R.drawable.like,
                R.drawable.heart,
                R.drawable.laughing,
                R.drawable.wow,
                R.drawable.sad,
                R.drawable.angry,
                R.drawable.crying
        };
        ReactionsConfig config = new ReactionsConfigBuilder(context)
                .withReactions(reactions)
                .build();
        ReactionPopup popup = new ReactionPopup(context, config, (pos) -> {
            if (pos<0)
                return false;

            if(holder.getClass() == SentViewHolder.class)
            {
                SentViewHolder viewHolder = (SentViewHolder) holder;
                viewHolder.binding.feeling.setImageResource(reactions[pos]);
                viewHolder.binding.feeling.setVisibility(View.VISIBLE);
            }
            else
            {
                ReceiverViewHolder viewHolder = (ReceiverViewHolder) holder;
                viewHolder.binding.feeling.setImageResource(reactions[pos]);
                viewHolder.binding.feeling.setVisibility(View.VISIBLE);
            }

            message.setFeeling(pos);
            FirebaseDatabase.getInstance().getReference()
                    .child("chats")
                    .child(senderRoom)
                    .child(receiveRoom)
                    .child("messages")
                    .child(message.getMessageId())
                    .setValue(message);

            FirebaseDatabase.getInstance().getReference()
                    .child("chats")
                    .child(receiveRoom)
                    .child(senderRoom)
                    .child("messages")
                    .child(message.getMessageId())
                    .setValue(message);

            return true; // true is closing popup, false is requesting a new selection
        });
        if(holder.getClass() == SentViewHolder.class) {
            SentViewHolder viewHolder = (SentViewHolder) holder;
            if(message.getMessage().equals("photo"))
            {
                viewHolder.binding.image.setVisibility(View.VISIBLE);

                viewHolder.binding.message.setVisibility(View.GONE);

                Glide.with(context).load(message.getImageUrl())
                        .placeholder(R.drawable.imageplaceholder)
                        .into(viewHolder.binding.image);

            }
            else if(message.getMessage().equals("doc"))
            {
                viewHolder.binding.image.setVisibility(View.VISIBLE);
                viewHolder.binding.image.setImageResource(R.drawable.file);
                viewHolder.binding.message.setVisibility(View.GONE);


            }
            viewHolder.binding.message.setText(message.getMessage());

            if (message.getFeeling() > -1) {
                viewHolder.binding.feeling.setImageResource(reactions[message.getFeeling()]);
                viewHolder.binding.feeling.setVisibility(View.VISIBLE);
            }
            else
            {
                viewHolder.binding.feeling.setVisibility(View.GONE);
            }
            viewHolder.binding.message.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popup.onTouch(v, event);
                    return false;
                }
            });

            viewHolder.binding.image.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    ///popup.onTouch(v, event)
                    if(message.getMessage().equals("photo")) {
                        String ImageR = message.getImageUrl();
                        Intent intent = new Intent(context, OpenImage.class);
                        intent.putExtra("ImageSend", ImageR);
                        context.startActivity(intent);
                    }
                    else if(message.getMessage().equals("doc"))
                    {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(message.getImageUrl()));
                        context.startActivity(intent);
                    }

                    return false;
                }
            });
        }
        else
        {
            ReceiverViewHolder viewHolder = (ReceiverViewHolder) holder;
            if(message.getMessage().equals("photo"))
            {
                viewHolder.binding.image.setVisibility(View.VISIBLE);
                viewHolder.binding.message.setVisibility(View.GONE);
                Glide.with(context).load(message.getImageUrl())
                        .placeholder(R.drawable.imageplaceholder)
                        .into(viewHolder.binding.image);

            }
            else if(message.getMessage().equals("doc"))
            {
                viewHolder.binding.image.setVisibility(View.VISIBLE);
                viewHolder.binding.image.setImageResource(R.drawable.file);
                viewHolder.binding.message.setVisibility(View.GONE);


            }
            viewHolder.binding.message.setText(message.getMessage());

            if (message.getFeeling() > -1) {
                //message.setFeeling(reactions[(int) message.getFeeling()]);
                viewHolder.binding.feeling.setImageResource(reactions[message.getFeeling()]);
                viewHolder.binding.feeling.setVisibility(View.VISIBLE);
            }
            else
            {
                viewHolder.binding.feeling.setVisibility(View.GONE);
            }

            viewHolder.binding.message.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popup.onTouch(v, event);
                    return false;
                }
            });

            viewHolder.binding.image.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    //popup.onTouch(v, event);
                    if(message.getMessage().equals("photo")) {
                        String ImageR = message.getImageUrl();
                        Intent intent = new Intent(context, OpenImage.class);
                        intent.putExtra("ImageSend", ImageR);
                        context.startActivity(intent);
                    }
                    else if(message.getMessage().equals("doc"))
                    {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(message.getImageUrl()));
                        context.startActivity(intent);
                    }
                    return false;
                }

            });

        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public class SentViewHolder extends RecyclerView.ViewHolder{
        ItemSendBinding binding;
        public SentViewHolder(@NonNull View itemView){
            super(itemView);
            binding = ItemSendBinding.bind(itemView);
        }
    }

    public class ReceiverViewHolder extends RecyclerView.ViewHolder
    {
        ItemReceiveBinding binding;
        public ReceiverViewHolder(@NonNull View itemView)
        {
            super(itemView);
            binding = ItemReceiveBinding.bind(itemView);
        }
    }



}